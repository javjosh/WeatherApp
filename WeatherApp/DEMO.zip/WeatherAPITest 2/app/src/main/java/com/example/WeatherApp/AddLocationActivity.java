package com.example.WeatherApp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.concurrent.ExecutionException;


//the view to add a new location
public class AddLocationActivity extends AppCompatActivity {
    private EditText locationInput;
    private String queryString = "";
    //the user's input is used to make the query to the API
    //we should have a method for the "Next" button that makes the query to the API with the user's input,
    //we then use the information that we get from the API to create a new Location object
    private  View view2;
    private TextView textView3;
    private RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_location);
        locationInput = findViewById(R.id.locationInput);
    }

    //the onClick for the Next Button
    public void doQuery(View view){
        queryString = locationInput.getText().toString();
        Location location = new Location();
        location.execute(queryString);
        try {
            //have a static method that can be used in the FetchWeather class that displays the toast message and cancels the query
            //if the result from the execute method is null then the API returned an error
            if(location.get().contains("null")){
                Toast toast = Toast.makeText(this, "Error ~ Please Enter A Valid Location",
                        Toast.LENGTH_SHORT);
                toast.show();
            }
            else if(!MainActivity.doesNotExist(queryString)){
                Toast toast = Toast.makeText(getApplicationContext(), "Error ~ This location already exists.",
                        Toast.LENGTH_SHORT);
                toast.show();
            }
            //destroy this view and open up a main activity view with the location added (if the query works)
            else{
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
