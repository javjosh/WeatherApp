package com.example.WeatherApp;

import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;

import okhttp3.Cache;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

//a class to connect to the internet and make queries to the API
public class FetchWeather {
    private static String locationName; //{location} name
    private static String actualTempF; //{current} temp_f
    private static String actualTempC; //{current} temp_c
    private static String feelLikeTempF; //{current} feelslike_f
    private static String feelLikeTempC; //{current} feelslike_c
    private static String windSpeedMph; //{current} wind_mph
    private static String windSpeedKph; //{current} wind_kph
    private static String windDirection; //{current} wind_dir
    private static String condition; //{current: {condition}} text
    private static String conditionImage; //{current}: {condition} icon
    private static String[] fetchWeatherVars = new String[10];


    public static String getWeatherInfo(String queryString) {
        //need a method to convert the commas to %2C and the spaces to %20 in queryString
        String weatherJSONString = null;
        try {
            OkHttpClient client = new OkHttpClient();

            Request request = new Request.Builder()
                    .url(prepareURL(queryString))
                    .get()
                    .addHeader("X-RapidAPI-Key", "c20b417fc9mshcb86374cfbc628bp189a3bjsn727cda1b60d1")
                    .addHeader("X-RapidAPI-Host", "weatherapi-com.p.rapidapi.com")
                    .build();

            Response response = client.newCall(request).execute();
            weatherJSONString = response.body().string();
        } catch (IOException e) {
            e.printStackTrace();
        }
        parseJSON(weatherJSONString);
        return Arrays.toString(fetchWeatherVars);
    }

    public static String prepareURL(String queryString){
        queryString.replace(" ", "");
        String[] queryStringArr = queryString.split("");
        String url;

        for(int i = 0; i < queryStringArr.length; i++){
            if(queryStringArr[i].equals(",")){
                queryStringArr[i] = "%2C";
            }
            if(queryStringArr[i].equals(":")){
                queryStringArr[i] = "%3A";
            }
        }
        queryString = String.join("",queryStringArr);
        url = "https://weatherapi-com.p.rapidapi.com/forecast.json?q=" + queryString + "&days=3";

        return url;
    }

    public static void parseJSON(String JSONString){
        try {
            JSONObject jsonObject = new JSONObject(JSONString);
            fetchWeatherVars = new String[10];
            if(!(jsonObject.has("error"))){
                JSONObject locationJSONObject = jsonObject.getJSONObject("location");
                locationName = locationJSONObject.getString("name");
                fetchWeatherVars[0] = locationName;
                JSONObject currentJSONObject = jsonObject.getJSONObject("current");
                actualTempF = currentJSONObject.getString("temp_f");
                actualTempC = currentJSONObject.getString("temp_c");
                feelLikeTempF = currentJSONObject.getString("feelslike_f");
                feelLikeTempC = currentJSONObject.getString("feelslike_c");
                windSpeedMph = currentJSONObject.getString("wind_mph");
                windSpeedKph = currentJSONObject.getString("wind_kph");
                windDirection = currentJSONObject.getString("wind_dir");
                fetchWeatherVars[1] = actualTempF;
                fetchWeatherVars[2] = actualTempC;
                fetchWeatherVars[3] = feelLikeTempF;
                fetchWeatherVars[4] = feelLikeTempC;
                fetchWeatherVars[5] = windSpeedMph;
                fetchWeatherVars[6] = windSpeedKph;
                fetchWeatherVars[7] = windDirection;

                JSONObject conditionJSONObject = currentJSONObject.getJSONObject("condition");
                condition = conditionJSONObject.getString("text");
                conditionImage = conditionJSONObject.getString("icon");
                fetchWeatherVars[8] = condition;
                fetchWeatherVars[9] = conditionImage;
            }
            else{
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
