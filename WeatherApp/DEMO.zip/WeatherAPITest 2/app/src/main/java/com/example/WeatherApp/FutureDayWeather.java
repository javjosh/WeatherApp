package com.example.WeatherApp;

import android.widget.ImageView;
import android.widget.TextView;

//this is an object for a location's future forecast day
//when a location is added, 3 of these objects are created and added to it's futureDays array
public class FutureDayWeather {
    private TextView tempHighF;
    private TextView tempLowF;
    private TextView tempHighC;
    private TextView tempLowC;
    private TextView condition;
    private ImageView conditionImage;
    private TextView dayOfTheWeek;
}
