package com.example.WeatherApp;

import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

//this will be the location class; NetworkUtils will become FetchWeather
//this is a separate class and extends AsynchTask so that NetoworkUtils (or connection to the internet and the API) can be executed on a different thread
public class Location extends AsyncTask<String, Void, String> {
    private String locationName;
    private String actualTemp;
    private String feelLikeTemp;
    private String windSpeed;
    private String actualTempF;
    private String actualTempC;
    private String feelLikeTempF;
    private String feelLikeTempC;
    private String windSpeedMph;
    private String windSpeedKph;
    private String windDirection;
    private String condition;
    private String conditionImage = "https:";
    private String[] fetchWeatherVars = new String[10];
    private String[] unitsUS = new String[3];
    private String[] unitsImp = new String[3];

    public Location(){
    }

    @Override
    //calls the query method getWeatherInfo from NetworkUtils
    //starts when FetchWeather.execute(String s) is called
    protected String doInBackground(String... strings) {
        return FetchWeather.getWeatherInfo(strings[0]);
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        //s is the response
        s = s.replace("[","");
        s = s.replace("]","");
        fetchWeatherVars = s.split(",");
        locationName = fetchWeatherVars[0];
        actualTempF = fetchWeatherVars[1] + " F";
        actualTempC = fetchWeatherVars[2];
        feelLikeTempF = fetchWeatherVars[3];
        feelLikeTempC = fetchWeatherVars[4];
        windSpeedMph = fetchWeatherVars[5];
        windSpeedKph = fetchWeatherVars[6];
        windDirection = fetchWeatherVars[7];
        condition = fetchWeatherVars[8];
        conditionImage += fetchWeatherVars[9].replace(" ","");

        //check if the location already exists
        //if it does then set the text to "this location already exists."
        MainActivity.addLocation(this);
    }

    public String getName(){
        return locationName;
    }

    public String getTemp() {
        return actualTempF;
    }

    public String getConditions() {
        return condition;
    }

    public String getConditionImage() {
        return conditionImage;
    }

    public void setupUnits(){
        unitsUS[0] = actualTempF + " F";
        unitsUS[1] = feelLikeTempF + " F";
        unitsUS[2] = windSpeedMph + " MPH";
        unitsImp[0] = actualTempC + " C";
        unitsImp[1] = feelLikeTemp + " C";
        unitsImp[2] = windSpeedKph + " KPH";

        actualTemp = unitsUS[0];
        feelLikeTemp = unitsUS[1];
        windSpeed = unitsUS[2];
    }

    public void switchToUnitsImp(View view){
        actualTemp = unitsImp[0];
        feelLikeTemp = unitsImp[1];
        windSpeed = unitsImp[2];
    }

    public void switchToUnitsUS(){
        actualTemp = unitsUS[0];
        feelLikeTemp = unitsUS[1];
        windSpeed = unitsUS[2];
    }
}
