package com.example.WeatherApp;

import android.widget.EditText;

//the view to add a new location
public class AddCityActivity {
    //the user's input is used to make the query to the API
    //we should have a method for the "Next" button that makes the query to the API with the user's input,
    //we then use the information that we get from the API to create a new Location object
    private EditText locationInput;
}
