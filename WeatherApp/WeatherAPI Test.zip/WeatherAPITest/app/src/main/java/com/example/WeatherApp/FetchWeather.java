package com.example.WeatherApp;

import android.os.AsyncTask;
import android.widget.ImageView;
import android.widget.TextView;

import java.lang.ref.WeakReference;

//this is a separate class and extends AsynchTask so that NetoworkUtils (or connection to the internet and the API) can be executed on a different thread
//constructor takes all of textviews as input
public class FetchWeather extends AsyncTask<String, Void, String> {
    private WeakReference<TextView> lLocationName;
    private WeakReference<TextView> lCurrTime;
    private WeakReference<TextView> lDayOfTheWeek;
    private WeakReference<TextView> lActualTempF;
    private WeakReference<TextView> lActualTempC;
    private WeakReference<TextView> lFeelLikeTempF;
    private WeakReference<TextView> lFeelLikeTempC;
    private WeakReference<TextView> lCondition;
    private WeakReference<ImageView> lConditionImage;
    private WeakReference<TextView> lWindSpeedM;
    private WeakReference<TextView> lWindSpeedK;
    private WeakReference<TextView> lWindDirection;

    public FetchWeather(TextView locationName, TextView currTime, TextView dayOfTheWeek, TextView actualTempF,
                        TextView actualTempC, TextView feelLikeTempF, TextView feelLikeTempC, TextView condition,
                        ImageView conditionImage, TextView windSpeedM, TextView windSpeedK, TextView windDirection) {
        lLocationName = new WeakReference<>(locationName);
        lCurrTime = new WeakReference<>(currTime);
        lDayOfTheWeek = new WeakReference<>(dayOfTheWeek);
        lActualTempF = new WeakReference<>(actualTempF);
        lActualTempC = new WeakReference<>(actualTempC);
        lFeelLikeTempF = new WeakReference<>(feelLikeTempF);
        lFeelLikeTempC = new WeakReference<>(feelLikeTempC);
        lCondition = new WeakReference<>(condition);
        lConditionImage = new WeakReference<>(conditionImage);
        lWindSpeedM = new WeakReference<>(windSpeedM);
        lWindSpeedK = new WeakReference<>(windSpeedK);
        lWindDirection = new WeakReference<>(windDirection);
    }

    public FetchWeather(String name){

    }

    @Override
    //calls the query method getWeatherInfo from NetworkUtils
    protected String doInBackground(String... strings) {
        return NetworkUtils.getWeatherInfo(strings[0]) ;
    }

    @Override
    //sets the textviews to their respective information from the API
    protected void onPostExecute(String s) {

        super.onPostExecute(s);
    }
}
