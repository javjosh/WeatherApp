package com.example.WeatherApp;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Location {
    private TextView locationName;
    private TextView currTime;
    //use java.util.Calendar
    private TextView dayOfTheWeek;
    private TextView actualTempF;
    private TextView actualTempC;
    private TextView feelLikeTempF;
    private TextView feelLikeTempC;
    private TextView condition;
    private ImageView conditionImage;
    private TextView windSpeedM;
    private TextView windSpeedK;
    private TextView windDirection;
    //array that stores this day's 3 day forecast
    private final FutureDayWeather[] futureDays = new FutureDayWeather[3];
    //the constructor should take one parameter, the name of the location
    //we use the name of the location to create a new FetchWeather object that we call AsynchTask.execute(
    public Location(String name){

    }

    public void searchLocations(View view){
        //new FetchWeather(locationName, currTime, dayOfTheWeek, actualTempF, actualTempC, feelLikeTempF, feelLikeTempC, condition, conditionImage, windSpeedM, windSpeedK, windDirection).execute(locationName.getText().toString());
        new FetchWeather("London").execute("London");
    }
}
