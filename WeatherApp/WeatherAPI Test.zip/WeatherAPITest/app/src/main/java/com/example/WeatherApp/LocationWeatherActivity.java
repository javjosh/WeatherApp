package com.example.WeatherApp;

//the location's current and 3 day forecast weather in one view
public class LocationWeatherActivity {
}
