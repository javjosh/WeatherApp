package com.example.WeatherApp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

//the main or homescreen of the app
public class MainActivity extends AppCompatActivity {
    //stores the user's locations and is used to display them on the MainActivity
    private ArrayList<Location> locations = new ArrayList<>();
    //have a method to remove locations


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void testQuery(View view){
        Location location = new Location("London");
        location.searchLocations(view);
    }
}