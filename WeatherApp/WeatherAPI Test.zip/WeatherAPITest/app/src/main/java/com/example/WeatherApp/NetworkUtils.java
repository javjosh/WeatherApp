package com.example.WeatherApp;

import android.net.Uri;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import okhttp3.Cache;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

//a class to connect to the internet and make queries to the API
public class NetworkUtils {
    private static final String LOG_TAG = "please";

    public static String getWeatherInfo(String queryString) {
        String weatherJSONString = null;

        try {
            OkHttpClient client = new OkHttpClient();

            Request request = new Request.Builder()
                    .url("https://weatherapi-com.p.rapidapi.com/forecast.json?q=London&days=3")
                    .get()
                    .addHeader("X-RapidAPI-Key", "c20b417fc9mshcb86374cfbc628bp189a3bjsn727cda1b60d1")
                    .addHeader("X-RapidAPI-Host", "weatherapi-com.p.rapidapi.com")
                    .build();

            Response response = client.newCall(request).execute();
            weatherJSONString = response.body().string();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Log.d(LOG_TAG,weatherJSONString);
        return weatherJSONString;
    }
}
